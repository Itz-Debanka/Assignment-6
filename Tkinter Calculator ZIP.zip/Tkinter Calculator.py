from tkinter import *
window = Tk()
window.title("Calculator")
window.geometry("500x500")
e=Entry(window,width=15,borderwidth=10,font=("times new roman",50))
e.place(x=0,y=0)
def entry(num):
    result=e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))




button1=Button(window,bg="green",text=1,height=5,width=10,font=("times new roman",10), command = lambda:entry(1))
button1.place(x=0,y=100)
button2=Button(window,bg="green",text=2,height=5,width=10,font=("times new roman",10), command = lambda:entry(2))
button2.place(x=100,y=100)
button3=Button(window,bg="green",text=3,height=5,width=10,font=("times new roman",10), command = lambda:entry(3))
button3.place(x=200,y=100)
button4=Button(window,bg="green",text=4,height=5,width=10,font=("times new roman",10), command = lambda:entry(4))
button4.place(x=0,y=200)
button5=Button(window,bg="green",text=5,height=5,width=10,font=("times new roman",10), command = lambda:entry(5))
button5.place(x=100,y=200)
button6=Button(window,bg="green",text=6,height=5,width=10,font=("times new roman",10), command = lambda:entry(6))
button6.place(x=200,y=200)
button7=Button(window,bg="green",text=7,height=5,width=10,font=("times new roman",10), command = lambda:entry(7))
button7.place(x=0,y=300)
button8=Button(window,bg="green",text=8,height=5,width=10,font=("times new roman",10), command = lambda:entry(8))
button8.place(x=100,y=300)
button9=Button(window,bg="green",text=9,height=5,width=10,font=("times new roman",10), command = lambda:entry(9))
button9.place(x=200,y=300)
button0=Button(window,bg="green",text=0,height=5,width=10,font=("times new roman",10),command = lambda:entry(0))
button0.place(x=100,y=400)
buttondot=Button(window,bg="green",text=".",height=5,width=10,font=("times new roman",10),command = lambda:entry("."))
buttondot.place(x=0,y=400)
def add():
    n1=e.get()
    global i
    global mathematics
    mathematics='addition'
    i=float(n1)
    e.delete(0,END)


def sub():
    n1 = e.get()
    global i
    global mathematics
    mathematics = 'subtraction'
    i = float(n1)
    e.delete(0, END)

def multi():
    n1=e.get()
    global i
    global mathematics
    mathematics = 'multiplication'
    i=float(n1)
    e.delete(0,END)

def div():
    n1=e.get()
    global i
    global mathematics
    mathematics = 'division'
    i=float(n1)
    e.delete(0,END)
def clr():
    e.delete(0,END)


def equal():
    n2=e.get()
    e.delete(0,END)
    if mathematics=='addition':
        e.insert(0,i+float(n2))
    elif mathematics=='subtraction':
        e.insert(0,i-float(n2))
    elif mathematics=='multiplication':
        e.insert(0,i*float(n2))
    elif mathematics=='division':
        try:
            e.insert(0,i/float(n2))
        except:
            e.insert(0,"UNDEFINED")



buttonplus=Button(window,bg="yellow",text="+",height=5,width=10,font=("times new roman",10),command=lambda:add())
buttonplus.place(x=300,y=100)
buttonminus=Button(window,bg="yellow",text="-",height=5,width=10,font=("times new roman",10),command=lambda:sub())
buttonminus.place(x=300,y=200)
buttonmulti=Button(window,bg="yellow",text="*",height=5,width=10,font=("times new roman",10),command=lambda:multi())
buttonmulti.place(x=300,y=300)
buttondiv=Button(window,bg="yellow",text="/",height=5,width=10,font=("times new roman",10),command=lambda:div())
buttondiv.place(x=300,y=400)
buttonclr=Button(window,bg="yellow",text="CE",height=5,width=10,font=("times new roman",10),command=clr)
buttonclr.place(x=200,y=400)

buttonequ=Button(window,bg="yellow",text="=",height=10,width=10,font=("times new roman",10),command=equal)
buttonequ.place(x=400,y=100)
window.mainloop()
